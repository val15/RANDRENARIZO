﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace simpleFischer
{
    /// <summary>
    /// Fenêtre de dialogue de choix de la couleur</summary>
    /// <remarks>
    /// La gestion du choix se fait au niveau de la classe Partie
    /// </remarks>
    public partial class Form_choix : Form
    {
        /// <summary>
        /// Constructeur de la classe. </summary>
        public Form_choix()
        {
            InitializeComponent();
        }

    }
}
